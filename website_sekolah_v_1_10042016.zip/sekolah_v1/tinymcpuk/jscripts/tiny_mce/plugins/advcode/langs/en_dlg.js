tinyMCE.addI18n('en.advcode_dlg',{
  title : 'HTML Source Editor',
  number_toggle : 'Line numbers'
})
