tinyMCE.addI18n('en.youtube',{
	desc : 'Insert youtube video'
});
