<?php
include "../config/koneksi.php";

$cek=umenu_akses("?module=iklantengah",$_SESSION[sessid]);
if($cek==1 OR $_SESSION[leveluser]=='admin'){
echo "<li><a href='?module=iklantengah'><b>Iklan Home</b></a></li>";
}



?>
