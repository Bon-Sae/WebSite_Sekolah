<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>

<?php

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION[leveluser]=='admin'){

$aksi="modul/mod_sekilasinfo/aksi_sekilasinfo.php";
switch($_GET[act]){
  // Tampil Sekilas Info
  default:
	echo "<div id=main-content> 
      <div class=container_12> 
      <div class=grid_12> 
      <br/>
	  <a href='?module=sekilasinfo&act=tambahsekilasinfo' class='button'>
	  <span>Tambah Sekilas Info</span>
      </a></div>";
	  
    echo "<div class=grid_12> 
      <div class=block-border> 
      <div class=block-header> 
      <h1>Halaman Baru</h1>
      <span></span> 
      </div> 
      <div class=block-content> 
      <table id=table-example class=table>
      <thead> 
          <tr><th>No</th><th>Info</th><th>Posting</th><th>Aksi</th></tr>
	  </thead>
	  <tbody>";
    $tampil=mysql_query("SELECT * FROM sekilasinfo ORDER BY id_sekilas DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl=tgl_indo($r[tgl_posting]);
      echo "<tr class=gradeX><td>$no</td>
                <td>$r[info]</td>
                <td>$tgl</td>
			
<td><a href=?module=sekilasinfo&act=editsekilasinfo&id=$r[id_sekilas] class='with-tip'>
<center><img src='img/edit.png'></a>

	  <a href=javascript:confirmdelete('$aksi?module=sekilasinfo&act=hapus&id=$r[id_sekilas]&namafile=$r[gambar]') class='with-tip'>
	  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a>			
		        </td></tr>";
    $no++;
    }
    echo "</tbody></table>";
    break;
  
  case "tambahsekilasinfo":
    echo "<div id='main-content'>
		  <div class='container_12'>

		  <div class='grid_12'>
		  <div class='block-border'>
		  <div class='block-header'>
			<h1>TAMBAHKAN SEKILAS INFO</h1>
		  </div>
		  <div class='block-content'>
          <form method=POST action='$aksi?module=sekilasinfo&act=input' enctype='multipart/form-data'>
          
		  <p class=inline-small-label> 
		   <label for=field4>Info</label>
		   <textarea name='info'  style='width: 720px; height: 250px;'></textarea>
		   </p><br/>
   		  
		   <div class=block-actions> 
		   <ul class=actions-right> 
		   <li>
		   <a class='button red' id=reset-validate-form href='?module=sekilasinfo'>Batal</a>
		   </li> </ul>
		   <ul class=actions-left> 
		   <li>
			  <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
		   </form>";
     break;
    
  case "editsekilasinfo":
    $edit = mysql_query("SELECT * FROM sekilasinfo WHERE id_sekilas='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

	    echo "<div id='main-content'>
		  <div class='container_12'>

		  <div class='grid_12'>
		  <div class='block-border'>
		  <div class='block-header'>
			<h1>EDIT SEKILAS INFO</h1>
		  </div>
		  <div class='block-content'>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=sekilasinfo&act=update>
          <input type='hidden' name='id' value='$r[id_sekilas]'>
		  <p class=inline-small-label> 
		   <label for=field4>Info</label>
		   <textarea name='info'  style='width: 720px; height: 250px;'>$r[info]</textarea>
		   </p><br/>
   		  
		   <div class=block-actions> 
		   <ul class=actions-right> 
		   <li>
		   <a class='button red' id=reset-validate-form href='?module=sekilasinfo'>Batal</a>
		   </li> </ul>
		   <ul class=actions-left> 
		   <li>
			  <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Update &nbsp;&nbsp;&nbsp;&nbsp;'>
		   </form>";
    break;  
}
//kurawal akhir hak akses module
} else {
	echo akses_salah();
}

?>
