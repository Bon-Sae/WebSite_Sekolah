<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>


<?php
//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION[leveluser]=='admin'){

$aksi="modul/mod_pengumuman/aksi_pengumuman.php";
switch($_GET[act]){
  // Tampil pengumuman
  
  default:
echo "<div id=main-content> 
      <div class=container_12> 
      <div class=grid_12> 
      <br/>
	  <a href='?module=pengumuman&act=tambahpengumuman' class='button'>
     <span>Tambahkan Pengumuman</span>
     </a></div>";

    if (empty($_GET['kata'])){
echo "<div class=grid_12> 
      <div class=block-border> 
      <div class=block-header> 
      <h1>SEMUA PENGUMUMAN</h1>
      <span></span> 
      </div> 
       <div class='block-content'>
		  
     <table id='table-example' class='table'>	  
  	  
    <thead><tr>
    <th>No</th>
    	<th>Judul</th>
    	<th>Nama File</th>
    	<th>Aksi</th>
    </thead>
    <tbody>";

    $p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);

    if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM pengumuman ORDER BY id_pengumuman DESC");
    }
    else{
      $tampil=mysql_query("SELECT * FROM pengumuman
                           WHERE username='$_SESSION[namauser]'       
                           ORDER BY id_pengumuman DESC");
    }
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

    if ($r[file_download]==''){
        $file = "<i style='color:red'>Tidak Ada File Disertakan</i>";
    }else{
        $file = $r[file_download];
    }

       echo "<tr class=gradeX> 
  <td width=50><center>$g</center></td>
  <td>$r[judul]</td>
  <td>$file</td>
  <td width=80>
  <a href='?module=pengumuman&act=editpengumuman&id=$r[id_pengumuman]' title='Edit' class='with-tip'>
  <center><img src='img/edit.png'></a>
   
  <a href=javascript:confirmdelete('$aksi?module=pengumuman&act=hapus&id=$r[id_pengumuman]') title='Hapus' class='with-tip'>
  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a> 
   
  </td></tr>";
  
      $no++;
      }
echo "</tbody></table> ";

      if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM pengumuman"));
      }
        else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM pengumuman WHERE username='$_SESSION[namauser]'"));
      }  
      break;    
      }
      else{
echo " <table id='table-example' class='table'>	  
	  
     <thead><tr>
     <th>No</th>
	<th>Judul</th>
	<th>Nama File</th>
	<th>Aksi</th>
  
     </thead>
     <tbody>";

      if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM pengumuman WHERE judul LIKE '%$_GET[kata]%' ORDER BY id_pengumuman DESC");
      }
      else{
      $tampil=mysql_query("SELECT * FROM pengumuman 
                           WHERE username='$_SESSION[namauser]'
                           AND judul LIKE '%$_GET[kata]%'       
                           ORDER BY id_pengumuman DESC");
      }
  
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
echo "<tr class=gradeX> 
  <td><center>$no</center></td>
  <td>$r[judul]</td>
  <td>$r[file_download]</td>
  <td>$tgl</td>
  <td width=80>
   
  <a href='?module=pengumuman&act=editpengumuman&id=$r[id_pengumuman]' title='Edit' class='with-tip'>
  <center><img src='img/edit.png'></a>
   
  <a href=javascript:confirmdelete('$aksi?module=pengumuman&act=hapus&id=$r[id_pengumuman]') title='Hapus' class='with-tip'>
  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a> 
   
  </td></tr>";
			 
  
      $no++;
     }
echo "</tbody></table> ";

      if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM pengumuman WHERE judul LIKE '%$_GET[kata]%'"));
      }
      else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM pengumuman WHERE username='$_SESSION[namauser]' AND judul LIKE '%$_GET[kata]%'"));
      }  
      break;    
      }
	  
//batas update/////////////////////////////////////////////////////////////////////////
  
  // Form Tambah Kategori
  case "tambahpengumuman":
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH PENGUMUMAN</h1>
   </div>
   <div class='block-content'>	
   
   <form method=POST action='$aksi?module=pengumuman&act=input' enctype='multipart/form-data'>
		  
   <p class=inline-small-label> 
   <label for=field4>Judul</label>
   <input type=text name='judul' size=40>
   </p> 
   
   <p class=inline-small-label> 
     <label for=field4>Keterangan</label>
    <textarea name='keterangan' style='width: 790px; height: 60px;'></textarea>
     </p>

   <p class=inline-small-label> 
   <label for=field4>Cari File</label>
   <input type=file name='fupload' size=40>
   </p> 
   
  	  
      <div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=pengumuman'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
     break;
  
  // Form Edit pengumuman
  case "editpengumuman":
  $edit = mysql_query("SELECT * FROM pengumuman WHERE id_pengumuman='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT FILE pengumuman</h1>
   </div>
   <div class='block-content'>	
	
   <form method=POST enctype='multipart/form-data' action=$aksi?module=pengumuman&act=update>
          <input type=hidden name=id value=$r[id_pengumuman]>
		  
   <p class=inline-small-label> 
   <label for=field4>Judul</label>
   <input type=text name='judul' size=40 value='$r[judul]'>
   </p>

   <p class=inline-small-label> 
     <label for=field4>Link Sambutan</label>
    <textarea name='keterangan' style='width: 790px; height: 60px;'>$r[keterangan]</textarea>
     </p>

   <p class=inline-small-label> 
   <label for=field4>File</label>
   $r[file_download]<br/>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Ganti File</label>
   <input type=file name='fupload' size=30>
   </p>";

	  echo " <br/><br/><div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=pengumuman'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
	  
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }
   ?>
   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>