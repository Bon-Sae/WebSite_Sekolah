
<?php 
echo "<div class='wrapper' style='padding-top:0px;'><br>
	<center>PHPMU ke Sekolah Duo © ".date('Y')." All Right Reserved</center>
</div>";


